let num=10;
let s:string="10";
s=null;
const a:boolean=false;
//a=true;
let b:any="0123";
let arr:any=[1,2,3,4,5,6,7,8,9];
let x:number|string="123";
x=26;
//alert(x.toString())