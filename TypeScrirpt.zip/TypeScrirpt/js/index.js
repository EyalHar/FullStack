console.log("hello world!");
//# sourceMappingURL=index.js.map